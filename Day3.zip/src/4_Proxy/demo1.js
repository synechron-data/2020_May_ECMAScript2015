// The Proxy object is used to define custom behavior for fundamental operations

// ‘in place of’, ‘representing’ or ‘on behalf of’ are literal meanings of proxy 

// Proxies are also called surrogates, handles, and wrappers.

// Control and manage access to the object you want to protect

// let errObject = {
//     code: "0x1001",
//     message: "Check you code for error"
// };

// console.log(errObject.code);
// console.log(errObject.message);
// console.log(errObject.source);

// --------------------------------------- Proxy
// var p = new Proxy(target, handler);

// target = Object which the proxy is wrapping
// handler  Object which contains a trap
// trap = Methods that provide fundamental operations
// Available traps - get, set, has, deleteProperty, construct, apply, isExtensible

// Target
let errObject = {
    code: "0x1001",
    message: "Check you code for error"
};

// Handler
let handler = {
    // Trap
    get: function(target, key){
        return key in target ? target[key] : `${key} - Property not Found...`;
    }
}

let errProxy = new Proxy(errObject, handler);
console.log(errProxy.code);
console.log(errProxy.message);
console.log(errProxy.source);
console.log(errProxy.errCode);