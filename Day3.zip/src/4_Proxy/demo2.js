var person = { age: 28 };
// person.age = "hi";
// console.log(person);

let handler = {
    set: function (target, key, value) {
        if (key === 'age') {
            if (typeof value != "number" || Number.isNaN(value))
                throw ('Age must be a number');
        }

        target[key] = value;
        return true;
    }
}

var personProxy = new Proxy(person, handler);

try {
    // personProxy.age = "hi";
    personProxy.age = 20;
    console.log(person);
} catch (e) {
    console.error(e);
    console.log(person);
}