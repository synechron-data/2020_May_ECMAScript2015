var promise = new Promise((resolve, reject) => {
    setTimeout(function () {
        // resolve("Hello, it is a success");
        reject("It is an error");
    }, 5000);
});

// promise.then((msg) => {
//     console.log("Success Block - ", msg);
// }, (eMsg) => {
//     console.error("Error Block - ", eMsg);
// });

// promise.then((msg) => {
//     console.log("Success Block - ", msg);
// }).catch((eMsg) => {
//     console.error("Error Block - ", eMsg);
// });

promise.then((msg) => {
    console.log("Success Block - ", msg);
}).catch((eMsg) => {
    console.error("Error Block - ", eMsg);
}).finally(() => {
    console.log("I will always run");
});