import localAPI from './localAPI';

document.getElementById("btnJS").addEventListener("click", function () {
    localAPI.getAllPostsUsingPromise().then((result) => {
        console.log(result);
    }, (eMsg) => {
        console.error(eMsg);
    });
});

// document.getElementById("btnJS").addEventListener("click", function () {
//     localAPI.getAllPosts((result) => {
//         console.log(result);
//     }, (eMsg) => {
//         console.error(eMsg);
//     });
// });

// document.getElementById("btnJS").addEventListener("click", function () {
//     fetch('https://jsonplaceholder.typicode.com/posts').then((response) => {
//         // console.log(response);
//         response.json().then(data => {
//             console.log(data);
//         }).catch((err) => {
//             console.error("Parsing Error");
//         })
//     }).catch((err) => {
//         console.error("Communication Error");
//     });
// });