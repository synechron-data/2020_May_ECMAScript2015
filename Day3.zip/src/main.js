// import './1_Iterators/1_Iterators';
// import './1_Iterators/2_Generators';

// import './2_Modules/usage';

// import './3_Promise/1_Promise';
// import './3_Promise/domHandlers';
// import './3_Promise/2_ChainingPromise';
import './3_Promise/3_PromiseMethods';

// import './4_Proxy/demo1';
// import './4_Proxy/demo2';

// document.getElementById("btnJS").addEventListener("click", function (e) {
//     alert("Button clicked.....");
//     // e.stopPropagation();
// });

// document.getElementById("div2").addEventListener("click", function () {
//     alert("Div 2 clicked.....");
// });

// document.getElementById("div1").addEventListener("click", function () {
//     alert("Div 1 clicked.....");
// });

// document.getElementById("btnJS").addEventListener("click", function (e) {
//     alert("Button clicked.....");
// }, true);

// document.getElementById("div2").addEventListener("click", function () {
//     alert("Div 2 clicked.....");
// }, true);

// document.getElementById("div1").addEventListener("click", function () {
//     alert("Div 1 clicked.....");
// }, true);