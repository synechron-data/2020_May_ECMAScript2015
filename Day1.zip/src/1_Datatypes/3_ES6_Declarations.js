// Block Scoped Variable

// let a = 10;
// console.log(a);
// console.log(typeof a);

// Hoisting - Hoisting is not allowed with let keyword
// a = 10;
// console.log(a);
// let a;

// Variable with same name cannot be created in the block
// let a = 10;
// let a = "Hello";

// console.log(a);

// ----------------------------------------------

// const must be initialized and cannot be re-initalized

// const env = "development";
// console.log(env);

// env = "production";
// console.log(env);

const person = { id: 1, name: "Manish" };
console.log(person);

// person = {};   // Error

person.name = "Abhijeet";
console.log(person);

