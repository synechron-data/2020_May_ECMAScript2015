// Add 'use strict' manually
// or
// use @babel/plugin-transform-strict-mode plugin

// console.log("Hello from Declaration File");

// a = 10;
// console.log(a);

// function test() {
//     a = 10;
//     console.log("Inside Test, a is", a);
// }

// test();
// console.log("Outside Test, a is", a);

// var a;
// a = 10;
// console.log(a);

// var b = 20;
// console.log(b);

// Hoisting - Hoisting is JavaScript's default behavior of moving declarations to the top.

// a = 10;
// console.log(a);
// var a;

// Definitions or Initializations are not hoisted

// console.log(a);
// var a = 10;

// Runtime will see the below code
// var a;
// console.log(a);
// a = 10;

var a = 10;
console.log(a);

a = "Manish";
console.log(a);

a = true;
console.log(a);

a = new Object();
console.log(a);