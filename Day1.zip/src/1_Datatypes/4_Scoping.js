// ES 5 - Scopes
// Global Scope
// Function Scope (Local Scope)

// var i = "Hello";
// console.log("Before, i is ", i);

// for (var i = 0; i < 5; i++) {
//     console.log("Inside Loop, i is", i);
// }

// for (var _i = 0; _i < 5; _i++) {
//     console.log("Inside Loop, i is", _i);
// }

// // function iterate() {
// //     for (var i = 0; i < 5; i++) {
// //         console.log("Inside Loop, i is", i);
// //     }
// // }

// // iterate();

// (function () {
//     for (var i = 0; i < 5; i++) {
//         console.log("Inside Loop, i is", i);
//     }
// })();

// console.log("After, i is ", i);

// ------------------------------------- ES 2015 - Scopes
// Global Scope
// Function Scope (Local Scope)
// Block Scope (Only when you use let or const)

// var i = "Hello";
// console.log("Before, i is ", i);

// for (let i = 0; i < 5; i++) {
//     console.log("Inside Loop, i is", i);
// }

// console.log("After, i is ", i);

// -------------------------------------------------- Query Poonam

for (var i = 0; i < 5; i++) {
    setTimeout(function () {
        console.log("Inside Loop, i is", i);
    }, 0);
}