// function <FunctionName>(<Parameters>) {
//     Function Body
// }

// function hello(person_name){
//     console.log("Hello,", person_name);
// }

// hello("Synechron");
// hello("Synechron", "Pune");
// hello();

// ------------------------------------- Handle Less Arguments

// Function to add, 2 numbers
// function add(x, y) {
//     x = x || 0;
//     y = y || 0;

//     if ((typeof x == "number") && (typeof y == "number"))
//         return x + y;

//     throw Error("Invalid Parameter Values...");
// }

// ES 2015 - Default Parameters
// function add(x = 0, y = 0) {
//     if ((typeof x == "number") && (typeof y == "number"))
//         return x + y;

//     throw Error("Invalid Parameter Values...");
// }

// console.log(add(2, 3));

// try {
//     // console.log(add(2, "ABC"));
//     console.log(add(2));
//     console.log(add());
// } catch (e) {
//     console.log(e.message);
// }

// ------------------------------------- Handle Extra Arguments
// function hello(person_name){
//     console.log("Hello,", person_name);
//     console.log(arguments);
// }

// ES 2015 - Rest Parameters (Combines comma seperated items to array)
// function hello(person_name, ...args){
//     console.log("Hello,", person_name);
//     console.log(args);
// }

// hello("Synechron");
// hello("Synechron", "Pune");
// hello("Synechron", "Pune", "Hinjewadi");
// hello("Synechron", "Pune", "Hinjewadi", "Phase 3");

// Variable Argument Methods
function average(...numbers) {
    // console.log(numbers);

    var sum = 0;

    for (let i = 0; i < numbers.length; i++) {
        sum += numbers[i];
    }

    if (numbers.length)
        return sum / numbers.length;
    else
        return sum;
}

console.log(average());
console.log(average(1));
console.log(average(1, 2));
console.log(average(1, 2, 3, 4, 5));
console.log(average(1, 2, 3, 4, 5, 6, 7, 8, 9));

var arr = [1, 2, 3, 4, 5, 6, 7, 8, 9];
console.log(average(...arr));      // Spread Operator
