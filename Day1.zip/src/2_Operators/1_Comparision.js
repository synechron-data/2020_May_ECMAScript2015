// JavaScript Numbers are Always 64-bit Floating Point

// var a = 32;

// console.log(a.toString());
// console.log(a.toString(2));
// console.log(a.toString(8));
// console.log(a.toString(16));

// var a = 32;         // base 10
// var b = 0b100000;   // base 2
// var c = 0o40;       // base 8
// var d = 0x20;       // base 16

// console.log(a);
// console.log(b);
// console.log(c);
// console.log(d);

// ------------------------------------------------

var a = 45;
var b = "45";

// console.log(typeof a);
// console.log(typeof b);

// var result1 = a == b;        // Abstract Equality
// console.log(result1);

// var result2 = a === b;        // Strict Equality
// console.log(result2);

var obj1 = new Object();
var obj2 = new Object();
var obj3 = obj1;

// console.log(obj1 == obj2);
// console.log(obj1 === obj2);

obj3.id = 1;
console.log(obj1);
console.log(obj3);

console.log(obj1 == obj3);
console.log(obj1 === obj3);