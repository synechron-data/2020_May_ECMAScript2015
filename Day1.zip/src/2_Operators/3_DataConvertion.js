// Type Casting - Between Similar (Same Family of) Types        int to float, float to double
// Type Coversion - Diff. Family of Types                       int to string, string to boolean

// JavaScript Supports Type Conversion

// var data = window.prompt("Enter a number", 0);
// // console.log(typeof data);

// // var d1 = data + 10;
// // console.log(d1);

// // var n1 = parseInt(data, 10);
// // console.log(n1);

// // var n1 = parseInt(data, 2);
// // console.log(n1);

// var n1 = parseInt(data) + 10;
// console.log(n1);

// var n2 = parseFloat(data) + 10;
// console.log(n2);

// var n3 = Number(data) + 10;
// console.log(n3);

// var obj = null;
// var obj;
// var obj = {};

// if ((obj === null) || (obj === undefined)) {
// if (!obj) {
//     console.log("Is Null or Undefined");
// } else {
//     console.log("Is Not Null or Not Undefined");
// }

// console.log(Boolean(1));
// console.log(Boolean(0));
// console.log(Boolean(-1));
// console.log(Boolean("ABC"));
// console.log(Boolean(""));
// console.log(Boolean(null));
// console.log(Boolean(undefined));
// console.log(Boolean({}));

// console.log(true && true);
// console.log(true && false);

// console.log(true && "ABC");
// console.log(true && "ABC" || "XYZ");
// console.log(false && "ABC" || "XYZ");

{/* <h1 class={{isSelected() && "text-info" || "text-danger">}}></h1>   */}

// T && T = T
// T && F = F

// It is not recommended to use eval() because it is slow, it is also not secured
// console.log(eval("5 + 5"));

// Number()
// String()
// Boolean()
// Symbol()