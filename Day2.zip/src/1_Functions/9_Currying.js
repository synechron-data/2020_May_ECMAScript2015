// function greetings(message, name) {
//     console.log(`${message}, ${name}`);
// }

// greetings("Good Morning", "Abhijeet");
// greetings("Good Morning", "Ramakant");
// greetings("Good Morning", "Pravin");

// function Converter(toUnit, factor, offset, input) {
//     return [((offset + input) * factor).toFixed(2), toUnit].join("");
// }

// console.log(Converter(" INR", 76, 0, 100));
// console.log(Converter(" INR", 76, 0, 120));
// console.log(Converter(" INR", 76, 0, 190));
// console.log(Converter(" INR", 76, 0, 900));

// -------------------------------------------------------------

// function greetings(message) {
//     return function (name) {
//         console.log(`${message}, ${name}`);
//     }
// }

// var mGreet = greetings("Good Morning");

// mGreet("Abhijeet");
// mGreet("Ramakant");
// mGreet("Pravin");

// const greetings = (message) => {
//     return (name) => {
//         console.log(`${message}, ${name}`);
//     }
// }

// var mGreet = greetings("Good Morning");

// mGreet("Abhijeet");
// mGreet("Ramakant");
// mGreet("Pravin");

// function Converter(toUnit, factor, offset) {
//     return function (input) {
//         return [((offset + input) * factor).toFixed(2), toUnit].join("");
//     }
// }

// var UsdToInr = Converter(" INR", 76, 0);

// console.log(UsdToInr(100));
// console.log(UsdToInr(120));
// console.log(UsdToInr(190));
// console.log(UsdToInr(900));

// ----------------------------------------------------------------------

// function greetings(message, name) {
//     console.log(`${message}, ${name}`);
// }

// function Converter(toUnit, factor, offset, input) {
//     return [((offset + input) * factor).toFixed(2), toUnit].join("");
// }

// var mGreet = greetings.bind(undefined, "Good Morning");

// mGreet("Abhijeet");
// mGreet("Ramakant");
// mGreet("Pravin");

// var UsdToInr = Converter.bind(undefined, " INR", 76, 0);

// console.log(UsdToInr(100));
// console.log(UsdToInr(120));
// console.log(UsdToInr(190));
// console.log(UsdToInr(900));

// ----------------------------------------

// function add(a, b, c) {
//     console.log(a + b + c);
// }

// function add(a) {
//     return function (b) {
//         return function (c) {
//             console.log(a + b + c);
//         }
//     }
// }

// const add = function (a) {
//     return function (b) {
//         return function (c) {
//             console.log(a + b + c);
//         }
//     }
// }

// const add = a => {
//     return b => {
//         return c => {
//             console.log(a + b + c);
//         }
//     }
// }

const add = a => b => c => {
    console.log(a + b + c);
}

// var add2 = add(2);
// var add3 = add2(3);

// add3(4);
// add3(5);
// add3(6);

add(2)(3)(4);
add(2)(3)(5);
add(2)(3)(6);