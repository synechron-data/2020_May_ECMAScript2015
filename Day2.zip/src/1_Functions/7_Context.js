// function Test() {
//     console.log(this);
// }

// const Test = function () {
//     console.log(this);
// }

// In ES6, arrow functions use lexical scoping — ‘this’ refers to it’s current surrounding scope and no further.
// const Test = () => {
//     console.log(this);
// }

// // Test();
// // Test.call();
// // Test.apply();

// var p1 = {
//     id: 1,
//     test: function () {
//         console.log(this);
//     }
// };

// // p1.test();

// Test();
// Test.call(p1);
// Test.apply(p1);

// -------------------------------------------------------- Function Borrowing

// var p1 = {
//     id: 1,
//     name: "Manish",
//     display: function () {
//         console.log(JSON.stringify(this));
//     }
// };

// var p2 = {
//     id: 2,
//     name: "Abhijeet",
//     display: function () {
//         console.log(JSON.stringify(this));
//     }
// };

// p1.display();
// p2.display();

// function display() {
//     console.log(JSON.stringify(this));
// }

// var p1 = {
//     id: 1,
//     name: "Manish"
// };

// var p2 = {
//     id: 2,
//     name: "Abhijeet"
// };

// // display.call(p1);
// // display.call(p2);

// p1.display = display.bind(p1);
// p2.display = display.bind(p2);

// p1.display();
// p2.display();

// ---------------------------------------- Call and Apply

// function Check(x, y) {
//     console.log(this);
//     console.log(`x= ${x}, y = ${y}`);
// }

// Check(2, 3);
// Check.call({ id: 1 }, 2, 3);
// Check.apply({ id: 2 }, [2, 3]);

// --------------------------------------

// function Person(age) {
//     this.age = age;

//     this.growOld = function () {
//         console.log(this);
//         this.age += 1;
//     }
// }

// var p1 = new Person(20);

// p1.growOld();
// console.log(p1.age);
// p1.growOld();
// console.log(p1.age);
// p1.growOld();
// console.log(p1.age);

// setInterval(p1.growOld, 2000);

// setInterval(function(){
//     console.log(p1.age);
// }, 2000);

// -------------------------------------------

// setInterval(p1.growOld.bind(p1), 2000);

// setInterval(function(){
//     console.log(p1.age);
// }, 2000);

// // --------------------------------------------- Lexical Scoping

// // In ES5 ‘this’ refers to the parent of the function and the object through which the function was called

// function Person(age) {
//     var self = this;
//     self.age = age;

//     self.growOld = function () {
//         self.age += 1;
//     }
// }

// var p1 = new Person(20);

// setInterval(p1.growOld, 2000);

// setInterval(function () {
//     console.log(p1.age);
// }, 2000);

// ---------------------------------------------

// In ES6, arrow functions use lexical scoping — ‘this’ refers to it’s current surrounding scope and no further.

function Person(age) {
    this.age = age;

    this.growOld = () => {
        this.age += 1;
    }
}

var p1 = new Person(20);

setInterval(p1.growOld, 2000);

setInterval(function () {
    console.log(p1.age);
}, 2000);