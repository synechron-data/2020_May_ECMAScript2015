// ---------------------------------------------------- Object.assign

// let source = { id: 1, name: "Manish", address: { city: "Pune" } };
// let target = {lastname: "Sharma"};

// let obj1 = Object.assign({}, source);
// console.log(obj1);

// let obj2 = Object.assign(target, source);
// console.log(obj2);

// console.log(target);
// console.log(source);

// console.log(target === obj2);

// ---------------------------------------------------- Object.create
// Creates a new object, using an existing object as the prototype of the newly created object.

// let source = { id: 1, name: "Manish", address: { city: "Pune" } };

// let newSource1 = Object.assign({}, source);
// let newSource2 = Object.create(source);

// console.log(source);
// console.log(newSource1);
// console.log(newSource2);

// ------------------------------------------------------

// let source = { id: 1, name: "Manish" };

// Object.preventExtensions(source);       // Adding New Property - Not Allowed
//                                         // Deleting Property - Allowed
//                                         // Modifying Property Value - Allowed
// source.id = 100;
// console.log(source);

// delete source.id;               
// console.log(source);

// if (Object.isExtensible(source)) {
//     source.city = "Pune";
//     console.log(source);
// }

// Object.seal(source);

//     source.id = 100;                // Modifying Property Value - Allowed
//     console.log(source);

// if (!Object.isSealed(source)) {
//     source.city = "Pune";           // Adding New Property - Not Allowed
//     console.log(source);

//     delete source.id;               // Deleting Property - Not Allowed
//     console.log(source);
// }

// Object.freeze(source);               // Modifying Property Value - Not Allowed
                                        // Adding New Property - Not Allowed
                                        // Deleting Property - Not Allowed

// if (!Object.isFrozen(source)) {
//     source.id = 100;
//     console.log(source);
//     source.city = "Pune";
//     console.log(source);
//     delete source.id;
//     console.log(source);
// }