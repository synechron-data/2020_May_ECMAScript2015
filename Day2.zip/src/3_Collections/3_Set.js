var set = new Set();

// console.log(set);
// console.log(typeof set);

set.add(1);
set.add(2);
set.add(3);
set.add(4);
set.add(5);

set.add(1);
set.add(2);
set.add(3);

// console.log(set);

for (const item of set) {
    console.log(item);
}