var map = new Map();
var wMap = new WeakMap();

(function () {
    var o1 = { id: 1 };
    var o2 = { id: 2 };

    map.set(o1, "This is the value for first object");
    wMap.set(o2, "This is the value for second object");
})();

console.log("Execution Completed....");