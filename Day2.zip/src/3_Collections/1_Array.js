// var employees = new Array();
// var employees = new Array(2);
// var employees = new Array("abc");
// var employees = [];

// var employees = Array.from([1, 2, 3, 4, 5]);
// var employees = Array.of(10, 20, 30, 40, 50);

// var employees = [10, 20, 30];

// employees[0] = "ABC";
// employees[1] = "ZYX";
// employees[2] = "YY";
// employees[5] = "QQQ";

// // console.log(employees);
// // console.log(typeof employees);
// // console.log(employees.length);

// // employees.unshift("Manish");
// employees.push("Manish");

// console.log(employees);

// --------------------------------------------- Iterate

// var employees = [
//     { id: 1, name: "Manish" },
//     { id: 2, name: "Varun" },
//     { id: 3, name: "Paresh" },
//     { id: 4, name: "Devesh" },
//     { id: 5, name: "Atul" },
// ];

// for (let i = 0; i < employees.length; i++) {
//     console.log(`${i}       ${JSON.stringify(employees[i])}`);    
// }

// employees.forEach((item,index, arr) =>{
//     console.log(`${index}       ${JSON.stringify(item)}`);
// });

// for(const item of employees){
//     console.log(`${JSON.stringify(item)}`);
// }

// for (const [index, item] of employees.entries()) {
//     console.log(`${index}       ${JSON.stringify(item)}`);
// }

// var r = employees.map((item) => {
//     return item.name.toUpperCase();
// });

// console.log(r);

// var numbers = [10, 20, 30, 40, 50];

// const reducerFn = function (accumulator, item) {
//     return accumulator + item;
// }

// console.log(numbers.reduce(reducerFn));

// console.log(numbers.reduce(function (accumulator, item) {
//     return accumulator + item;
// }));

// console.log(numbers.reduce((accumulator, item) => accumulator + item, 100));

// ----------------------------------------------------- Query

var employees = [
    { id: 1, name: "Manish" },
    { id: 2, name: "Varun" },
    { id: 3, name: "Paresh" },
    { id: 4, name: "Devesh" },
    { id: 5, name: "Atul" },
];

var r1 = employees.map((item) => {
    return item.name.toUpperCase();
});

console.log(r1);

var r2 = employees.filter((item) => {
    return item.name.startsWith('A');
});

console.log(r2);