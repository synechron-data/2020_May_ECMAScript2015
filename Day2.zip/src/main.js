// import './1_Functions/1_PureAndImpureFn';
// import './1_Functions/2_FnOverloading';
// import './1_Functions/3_IIFE.js';
// import './1_Functions/4_OverloadingAssign';
// import './1_Functions/5_ArrowFunctions';
// import './1_Functions/6_FnAsParameter';
// import './1_Functions/7_Context';
// import './1_Functions/8_Closure';
// import './1_Functions/9_Currying';

// import './2_Types/1_ObjectCreation';
// import './2_Types/2_ObjectType';
// import './2_Types/3_ObjectMethods';
// import './2_Types/4_CustomType';
// import './2_Types/5_UsingPrototype';
// import './2_Types/6_ES6_Class';
// import './2_Types/7_Compare';
// import './2_Types/8_ES5_Properties';
// import './2_Types/9_ES6_Properties';
// import './2_Types/10_StaticMembers';
// import './2_Types/11_ES5_Inheritance';
// import './2_Types/12_ES6_Inheritance';

import './3_Collections/1_Array';
// import './3_Collections/2_Map';
// import './3_Collections/3_Set';
// import './3_Collections/4_WeakMap';


